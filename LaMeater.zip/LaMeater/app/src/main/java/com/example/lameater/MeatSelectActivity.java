package com.example.lameater;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MeatSelectActivity extends AppCompatActivity {
    // Create variables for button
    private Button beefbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meat_select);

        // Beef select button activity
        beefbutton = (Button) findViewById(R.id.beefbutton);
        // What to do when button is pressed
        beefbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openBeefActivity();
            }
        });
    }

    // Creates onLoginSuccessful function when button clicked
    public void openBeefActivity() {
        Intent intent = new Intent(this, BeefActivity.class);
        startActivity(intent);
    }
}
