package com.example.lameater;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class TempWatchActivity extends AppCompatActivity {
    // Create variables for button
    private Button backbutton3;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temp_watch);

        // Back button activity
        backbutton3 = (Button) findViewById(R.id.backbutton3);
        // What to do when button is pressed
        backbutton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openBrisketMeatActivity();
            }
        });
    }

    // Creates function when back button clicked
    public void openBrisketMeatActivity() {
        Intent intent = new Intent(this, BrisketMeatActivity.class);
        startActivity(intent);
    }
}
