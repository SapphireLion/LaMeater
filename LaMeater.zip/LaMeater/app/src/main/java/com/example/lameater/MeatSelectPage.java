package com.example.lameater;

public class MeatSelectPage {
}
