package com.example.lameater;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class BrisketMeatActivity extends AppCompatActivity {

    // Create variables for button
    private Button backbutton2;
    private Button nextbutton2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_brisket_meat);

        // Back type select button activity
        backbutton2 = (Button) findViewById(R.id.backbutton2);
        // What to do when button is pressed
        backbutton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openBeefActivity();
            }
        });

        // Next button activity
        nextbutton2 = (Button) findViewById(R.id.nextbutton2);
        // What to do when button is pressed
        nextbutton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openTempWatchActivity();
            }
        });

    }

    // Creates openBeefActivity function when button clicked
    public void openBeefActivity() {
        Intent intent = new Intent(this, TempWatchActivity.class);
        startActivity(intent);


    }

    // Creates openTempWatchActivity function when button clicked
    public void openTempWatchActivity() {
        Intent intent = new Intent(this, TempWatchActivity.class);
        startActivity(intent);
    }
}
