package com.example.lameater;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    // Create variables for button
    private Button startbutton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Login button activity
        startbutton = (Button) findViewById(R.id.startbutton);
        // What to do when button is pressed
        startbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMyPage();
            }
        });
    }


    // Creates onClick function when button clicked
    public void openMyPage() {
        Intent intent = new Intent(this, MeatSelectActivity.class);
        startActivity(intent);
    }
}
