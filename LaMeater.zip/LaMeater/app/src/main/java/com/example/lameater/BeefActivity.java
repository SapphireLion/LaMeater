package com.example.lameater;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class BeefActivity extends AppCompatActivity {
    // Create variables for button
    private Button brisketbutton;
    private Button backbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beef);

        // Beef type select button activity
        brisketbutton = (Button) findViewById(R.id.brisketbutton);
        // What to do when button is pressed
        brisketbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openBeefActivity();
            }
        });

        // Back button activity
        backbutton = (Button) findViewById(R.id.backbutton);
        // What to do when button is pressed
        backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMeatSelectActivity();
            }
        });
    }

    // Creates openBeefActivity function when button clicked
    public void openBeefActivity() {
        Intent intent = new Intent(this, BrisketMeatActivity.class);
        startActivity(intent);
    }

    // Creates openBeefActivity function when button clicked
    public void openMeatSelectActivity() {
        Intent intent = new Intent(this, MeatSelectActivity.class);
        startActivity(intent);
    }
}
